package code.with.cal.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import code.with.cal.tictactoe.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity()
{
    enum class Go
    {
        O,
        X
    }

    private var first_go = Go.X // Zmienna przechowująca informację o pierwszym ruchu, zaczyna gracz X
    private var current_go = Go.X // Zmienna przechowująca informację o aktualnym ruchu

    private var xScore = 0 // Licznik punktów dla gracza X
    private var oScore = 0 // Licznik punktów dla gracza O

    private var board = mutableListOf<Button>() // Lista przycisków planszy

    private lateinit var bind : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)
        boardInitialization()
    }

    private fun boardInitialization() {
        with(bind) {
            board.apply {
                add(r1c1)
                add(r1c2)
                add(r1c3)
                add(r2c1)
                add(r2c2)
                add(r2c3)
                add(r3c1)
                add(r3c2)
                add(r3c3)
            }
        }
    }

    fun boardTapped(view: View)
    {
        if(view !is Button)
            return
        addElement(view)

        if(checkTheWin(O))
        {
            oScore++
            score("O is the winner!") // Wyświetl komunikat o wygranej gracza O
        }
        else if(checkTheWin(X))
        {
            xScore++
            score("X is the winner!") // Wyświetl komunikat o wygranej gracza X
        }

        if(draw())
        {
            score("Draw in the game") // Wyświetl komunikat o remisie
        }

    }

    private fun checkTheWin(s: String): Boolean {

        with(bind) {
            // Sprawdź poziome linie
            if (match(r1c1, s) && match(r1c2, s) && match(r1c3, s))
                return true
            if (match(r2c1, s) && match(r2c2, s) && match(r2c3, s))
                return true
            if (match(r3c1, s) && match(r3c2, s) && match(r3c3, s))
                return true

            // Sprawdź pionowe linie
            if (match(r1c1, s) && match(r2c1, s) && match(r3c1, s))
                return true
            if (match(r1c2, s) && match(r2c2, s) && match(r3c2, s))
                return true
            if (match(r1c3, s) && match(r2c3, s) && match(r3c3, s))
                return true

            /// Sprawdź skośne linie
            if (match(r1c1, s) && match(r2c2, s) && match(r3c3, s))
                return true
            if (match(r1c3, s) && match(r2c2, s) && match(r3c1, s))
                return true
        }

        return false
    }

    private fun match(button: Button, symbol : String): Boolean = button.text == symbol

    private fun score(title: String)
    {
        val message = "\nScore O: $oScore\n\nScore X: $xScore" // Wiadomość zawierająca aktualny wynik
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Play again")
            { _,_ ->
                reset()
            }
            .setCancelable(false)
            .show()
    }

    private fun reset()
    {
        for(button in board)
        {
            button.text = ""
        }

        if(first_go == Go.O)
            first_go = Go.X // Zmień pierwszy ruch na gracza X
        else if(first_go == Go.X)
            first_go = Go.O // Zmień pierwszy ruch na gracza O

        current_go = first_go
        setGoName()
    }

    private fun draw(): Boolean
    {
        for(button in board)
        {
            if(button.text == "")
                return false
        }
        return true // Wszystkie przyciski są wypełnione, remis
    }
    // Dodaj element do planszy
    private fun addElement(button: Button)
    {
        if(button.text != "")
            return

        if(current_go == Go.O)
        {
            button.text = O
            current_go = Go.X
        }
        else if(current_go == Go.X)
        {
            button.text = X
            current_go = Go.O
        }
        setGoName()
    }
    // Ustaw nazwę aktualnego gracza
    private fun setGoName()
    {
        var turnText = ""
        if(current_go == Go.X)
            turnText = "Go -> $X"
        else if(current_go == Go.O)
            turnText = "Go -> $O"

        bind.turnTV.text = turnText
    }

    companion object
    {
        const val O = "O" // Stała reprezentująca symbol "O"
        const val X = "X" // Stała reprezentująca symbol "X"
    }

}

